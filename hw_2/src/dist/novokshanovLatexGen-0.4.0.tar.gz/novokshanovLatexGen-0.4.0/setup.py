
from setuptools import setup, find_packages

setup(
    name='novokshanovLatexGen',
    version='0.4.0',
    description='Library to generate LaTeX code for tables and images.',
    author='novokshanov.e',
    author_email='novokshanov.eugene@yandex.ru',
    packages=find_packages(),
    install_requires=[],
)
